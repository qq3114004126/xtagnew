package com.example.springbootweb.dao;

import com.example.springbootweb.vo.HiveTableFields;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Map;

@Mapper
public interface DBTableRelationInsertMapper {

    int insertTableRelationInformation(HiveTableFields hiveTableFields);

    String selectTables();

    List<String> showTables(@PathVariable("database") String database);

    List<Map<String,String>> selectTableRelations();

    List<String> describeTableName(@Param("tableName") String tableName);

    List<HiveTableFields> showRelationTables();

    List<HiveTableFields> isExistSourceTableName(@Param("tableName") String tableName);

    Integer selectMaxRelation(@Param("tableName") String tableName);
}
