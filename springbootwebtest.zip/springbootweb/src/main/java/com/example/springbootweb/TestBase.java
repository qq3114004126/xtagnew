package com.example.springbootweb;

import com.example.springbootweb.service.HiveTableRelations;
import com.example.springbootweb.service.TestInsert;
import com.example.springbootweb.vo.HiveTableFields;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringbootwebApplication.class)
public class TestBase {

    @Autowired
    TestInsert testInsert;

    @Autowired
    HiveTableRelations hiveTableRelations;
    @Test
    public void after() throws Exception {
//        List<HiveTableFields> tableRelations = hiveTableRelations.getTableRelations(sourceTableName);
////        System.out.println(tableRelations);
//        Boolean sourcre = hiveTableRelations.isExistSourceTableName("hive001");
//        System.out.println(sourcre);
        Boolean tableRelation = hiveTableRelations.insertHiveTableRelation("23sasdf", "sfdsw89eq001", "2343ewad", "sqd");
        System.out.println(tableRelation);
    }
}
