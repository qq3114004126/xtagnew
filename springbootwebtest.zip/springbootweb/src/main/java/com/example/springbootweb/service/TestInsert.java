package com.example.springbootweb.service;


import com.example.springbootweb.dao.DBTableRelationInsertMapper;
import com.example.springbootweb.vo.HiveTableFields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestInsert {

    private static final Logger log = LoggerFactory.getLogger(TestInsert.class);

    @Autowired
    DBTableRelationInsertMapper dbTableRelationInsert;

    public Boolean insertVo() {
        boolean flag = false;

        HiveTableFields hiveTableFields = new HiveTableFields("hive001","id","hbase001","id",2,"t_hive_table_relation");
        int tableRelationInformation = dbTableRelationInsert.insertTableRelationInformation(hiveTableFields);
        if (tableRelationInformation>0) {
            log.info("success!");
            return true;
        }else {
            log.info("failed!");
            return false;
        }
    }
}
