package com.example.springbootweb.controller;

import com.example.springbootweb.dao.DBTableRelationInsertMapper;
import com.example.springbootweb.service.HiveTableRelations;
import com.example.springbootweb.vo.HiveTableFields;
import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
public class HiveController {

    private static final Logger LOG = LoggerFactory.getLogger(HiveController.class);
//    @Autowired
//    Connection conn;

    @Autowired
    HiveTableRelations hiveTableRelations;

    @Autowired
    DBTableRelationInsertMapper dbTableRelationInsert;

    @GetMapping("/hello")
    @ResponseBody
    public String helloContrller() {
        return "hello world!";
    }

    @GetMapping("/showtables/{database}")
    @ResponseBody
    public List<String> getTables(@Param("database") String database) {
        List<String> strings = dbTableRelationInsert.showTables(database);
        return strings;
    }

    @GetMapping("/hivetable")
    @ResponseBody
    public List<Map<String,String>> getTableRelations() {
        List<Map<String, String>> maps = dbTableRelationInsert.selectTableRelations();
        return maps;
    }

    @GetMapping("/hivetablefields/{tableName}")
    @ResponseBody
    public List<String> getTableFields(@PathVariable("tableName") String tableName) {
        List<String> describeTableName = dbTableRelationInsert.describeTableName(tableName);
        return describeTableName;
    }

//    @GetMapping("/hiveList")
//    @ResponseBody
//    public List<HiveTableFields> getHiveTableRelation() {
//        //List<HiveTableFields> tableRelations = hiveTableRelations.getTableRelations(sourceTableName);
//        return tableRelations;
//    }
//  String sourceTableName,String sourceTableRelationField,String targetTableName,String targetRelationField
    @GetMapping("/insert/{sourceTableName}/{sourceTableRelationField}/{targetTableName}/{targetRelationField}")
    @ResponseBody
    public int getStatus(@PathVariable("sourceTableName") String sourceTableName,
                         @PathVariable("sourceTableRelationField") String sourceTableRelationField,
                         @PathVariable("targetTableName") String targetTableName,
                         @PathVariable("targetRelationField") String targetRelationField) {
        try {
            Boolean insertHiveTableRelation = hiveTableRelations.insertHiveTableRelation(sourceTableName, sourceTableRelationField, targetTableName, targetRelationField);
        } catch (Exception e) {
            LOG.error("insert failed!");
        }
        return 200;
    }















}
