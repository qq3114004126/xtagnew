package com.example.springbootweb.service;

import com.example.springbootweb.dao.DBTableRelationInsertMapper;
import com.example.springbootweb.vo.HiveTableFields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Service
public class HiveTableRelations {

    private static final Logger LOG = LoggerFactory.getLogger(HiveTableRelations.class);

    /**
     *
     * 判断relation的层级
     * @return
     */

    @Autowired
    DBTableRelationInsertMapper dbTableRelationInsertMapper;

    public List<HiveTableFields> getTableRelations() {
        List<HiveTableFields> hiveTableFields = dbTableRelationInsertMapper.showRelationTables();
        return hiveTableFields;
    }

//    public int getRelation(String sourceTableName) throws Exception {
//        List<HiveTableFields> tableRelations = getTableRelations();
//        if (CollectionUtils.isEmpty(tableRelations)) {
//            LOG.error("tableRelations is null!");
//            throw new Exception("tableRelations is null!");
//        }
//        int relation = 0;
//        for (HiveTableFields s:tableRelations) {
//            if (s.equals(sourceTableName)) {
//                relation = s.getRelation();
//                LOG.info("tableName is exists!");
//                relation++;
//            }else {
//                LOG.info("新增一条数据!");
//                relation = 1;
//            }
//        }
//        return relation;
//    }


    public Boolean isExistSourceTableName(String sourceTableName) {
        boolean flag = false;
        List<HiveTableFields> existSourceTableName = dbTableRelationInsertMapper.isExistSourceTableName(sourceTableName);
        if (CollectionUtils.isEmpty(existSourceTableName)) {
            flag = false;
            LOG.error("sourceTableName is not exists!");
        }else {
            flag = true;
            LOG.info("sourceTableName exists");
        }
        return flag;
    }

    /**
     *
     * @param sourceTableName
     * @param sourceTableRelationField
     * @param targetTableName
     * @param targetRelationField
     * @return
     * @throws Exception
     */

    public Boolean insertHiveTableRelation(String sourceTableName,String sourceTableRelationField,String targetTableName,String targetRelationField) throws Exception {
        Boolean flag = false;
        Boolean existSourceTableName = isExistSourceTableName(sourceTableName);
        HiveTableFields hiveTableFields = new HiveTableFields();
        int relation = 0;
        if (existSourceTableName==false) {
            relation =1;
            LOG.info("sourceTableName is exists");
            hiveTableFields.setSourceTableName(sourceTableName);
            hiveTableFields.setSourceTableRelatiobField(sourceTableRelationField);
            hiveTableFields.setTargetTableName(targetTableName);
            hiveTableFields.setTargetRelationField(targetRelationField);
            hiveTableFields.setRelation(relation);
            hiveTableFields.setTableRelationName("t_hive_table_relation");
            // 插入数据
            dbTableRelationInsertMapper.insertTableRelationInformation(hiveTableFields);
            flag = true;
        }else {
            List<HiveTableFields> tableRelationsList = getTableRelations();
           boolean tag = getSameResultRecord(sourceTableName, sourceTableRelationField, targetTableName, targetRelationField);
            if (tag) {
                LOG.error("data exists,no need insert data!");
                throw new Exception("Record has exists!");
            }else {
                relation = dbTableRelationInsertMapper.selectMaxRelation(sourceTableName);
                relation = relation +1;
                hiveTableFields.setSourceTableName(sourceTableName);
                hiveTableFields.setSourceTableRelatiobField(sourceTableRelationField);
                hiveTableFields.setTargetTableName(targetTableName);
                hiveTableFields.setTargetRelationField(targetRelationField);
                hiveTableFields.setRelation(relation);
                hiveTableFields.setTableRelationName("t_hive_table_relation");
                dbTableRelationInsertMapper.insertTableRelationInformation(hiveTableFields);
                flag = true;
            }

        }
        return flag;
    }

    /**
     * 判断是否存在相同的记录
     */
    public Boolean getSameResultRecord(String tableName,String field,String targetName,String targetField) throws Exception {
        Boolean flag = false;
        List<HiveTableFields> tableRelations = getTableRelations();
        LOG.info("获取关联表信息集合！");
        for (HiveTableFields h:tableRelations) {
            //ArrayList<String> tableRelationList = new ArrayList<>();
            String sourceTableName = h.getSourceTableName();
            String sourceTableRelatiobField = h.getSourceTableRelatiobField();
            String targetTableName = h.getTargetTableName();
            String targetRelationField = h.getTargetRelationField();
            if (sourceTableName==tableName & targetTableName==targetName & sourceTableRelatiobField==field & targetRelationField==targetField) {
                flag = true;
                LOG.error("exist same data record!");
                throw new Exception("exist same data record!");
            }else{
                flag = false;
            }
        }
        return flag;
    }

}
