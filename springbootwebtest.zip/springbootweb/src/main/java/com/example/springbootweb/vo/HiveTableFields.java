package com.example.springbootweb.vo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.annotation.sql.DataSourceDefinition;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class HiveTableFields {


    // 原始表
    private String sourceTableName;
    private String sourceTableRelatiobField;
    private String targetTableName;
    private String targetRelationField;
    private Integer relation;
    private String tableRelationName;

}
