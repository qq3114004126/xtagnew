package com.example.web.springweb.controller;


import com.example.web.springweb.dao.BookDao;
import com.example.web.springweb.entity.Book;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/book")
public class BookController {

    @Resource
    private BookDao bookDao;

    //查询所有图书
    @RequestMapping("/list")
    public ModelAndView list() {
        ModelAndView mav = new ModelAndView();
        mav.addObject("booklist",bookDao.findAll());
        mav.setViewName("bookList");
        return mav;
    }

    // 添加图书
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public String add(Book book) {
        bookDao.save(book);
        return "forward:/book/list";
    }

    // 根据ID 查询图书
    @RequestMapping("/preUpdate/{id}")
    public ModelAndView preUpdate(@PathVariable("id") Integer id){
        ModelAndView mav = new ModelAndView();
        mav.addObject("book",bookDao.getOne(id));
        mav.setViewName("bookUpdate");
        return mav;
    }

    // 修改图书
    @RequestMapping(value = "/update")
    public String update(Book book) {
        bookDao.save(book);
        return "forward:/book/list";
    }
    @GetMapping("/delete")
    public String delete(Integer id) {
        bookDao.deleteById(id);
        return "forward:/book/list";
    }

    // 查询
    @ResponseBody
    @RequestMapping("/query")
    public List<Book> findByName(String name) {
        return bookDao.findByName("思想");
    }

    @ResponseBody
    @RequestMapping("/randomlist")
    public List<Book> randomList(String name) {
        return bookDao.randomList(2);
    }
}
